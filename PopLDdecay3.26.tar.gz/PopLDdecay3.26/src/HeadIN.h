
#ifndef HeadIN_H_
#define HeadIN_H_

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <iomanip>
#include <math.h>
#include <cstdlib>

#include "./include/zlib/zlib.h"
#include "./include/gzstream/gzstream.h"

#include "./DataClass.h"
#include "./CommFun.h"

//#include <stdio.h>
//#include <ctime>
//
#endif  // end HeadIN 


